
(function() {

angular.module('botApp', [])
  .controller('BotController', ['$scope', '$filter', BotController]);

  function BotController($scope, $filter) {
    $scope.field = "word";
    $scope.order = "0";
    $scope.itemPerPage = "2";
    $scope.currentPage = 0;
    $scope.pages = [];
    var nbPages = 0;

    var sentences = [
      {
        word: "a",
        response: "d"
      },
      {
        word: "b",
        response: "c"
      },
      {
        word: "c",
        response: "b"
      },
      {
        word: "d",
        response: "a"
      }
    ];

    $scope.$watch('itemPerPage', function(newValue, oldValue) {
      calcItems();
    });

    function calcItems() {
      var ipp = Number($scope.itemPerPage);
      nbPages = Math.ceil(sentences.length / ipp);

      $scope.pages = [];

      for(var i = 0; i < nbPages; i++) {
        $scope.pages.push(i);
      }

      refreshSentences();
    }

    $scope.$watch('currentPage', function(newValue, oldValue) {
      refreshSentences();
    });

    function refreshSentences() {
      var ipp = Number($scope.itemPerPage);
      var idx = $scope.currentPage * ipp;
      $scope.stcs = sentences.slice(idx, (idx + ipp));
    }

    $scope.changePage = function() {
      $scope.currentPage = this.i;
    }

    $scope.delete = function(sentence) {
      var idx = sentences.indexOf(sentence);

      sentences.splice(idx, 1);

      $scope.stcs = sentences;

      calcItems();
    }

    /*$scope.$watch('order', function(newValue, oldValue) {
      $scope.rev = $scope.order == "1";
    });*/

    $scope.reverse = function() {
      var rev = $scope.order == "1";
      sentences = $filter('orderBy')(sentences, $scope.field, rev);
      refreshSentences();
    }

    $scope.previous = function() {
      if($scope.currentPage > 0) {
        $scope.currentPage--;
      }
    }

    $scope.next = function() {
      if($scope.currentPage < nbPages - 1) {
        $scope.currentPage++;
      }
    }

  }

})();
